<?php

class dummy extends phplistTest
{
    public $name = 'Dummy test';
    public $purpose = 'Just an initial dummy test';

    public function runtest()
    {
        return 1;
    }
}

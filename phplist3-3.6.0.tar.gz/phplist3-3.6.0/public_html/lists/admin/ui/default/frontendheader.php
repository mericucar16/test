<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link rel="apple-touch-icon" href="./images/phplist-touch-icon.png" />
<link rel="apple-touch-icon-precomposed" href="./images/phplist-touch-icon.png" />
<link rel="stylesheet" href="styles/subscribe.css" type="text/css" />
<link rel="stylesheet" href="styles/color.css" type="text/css" />
</head>

<body class="fixed">

<div id="container">

<div id="header" >
<div id="rack-functions">
<h1 id="logo"><a href="http://[WEBSITE]" title="Visit our website">[ORGANISATION_NAME]</a></h1>
</div>
</div>
<div id="wrapper">
<div id="mainContent">

<div class="panel">
<div class="content">
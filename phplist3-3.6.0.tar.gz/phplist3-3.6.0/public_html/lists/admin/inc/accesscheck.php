<?php

if (!function_exists('checkAccess')) {
    echo 'Invalid Request';
    exit;
}

<?php

//# this will keep the session alive, but we may not want to extend it forever either.
$status = '';

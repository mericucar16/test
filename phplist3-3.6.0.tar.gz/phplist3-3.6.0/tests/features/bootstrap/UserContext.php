<?php

use Behat\Behat\Context\Context;

class UserContext implements Context
{
    public function iAmLoggedInAs($user, $password)
    {

    }
}
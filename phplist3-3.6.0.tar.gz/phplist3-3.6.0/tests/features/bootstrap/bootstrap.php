<?php

$lib = __DIR__.'/../../../public_html/lists/admin';

include_once $lib.'/inc/random_compat/random.php';
include_once $lib.'/inc/UUID.php';